sudo apt-get install build-essential
sudo apt-get install cmake
sudo apt-get install pkg-config
sudo apt-get install libpng12-0
sudo apt-get install libpng12-dev
sudo apt-get install libpng++-dev
sudo apt-get install libpng3
sudo apt-get install libpnglite-dev
sudo apt-get install libpngwriter0-dev
sudo apt-get install libpngwriter0c2
sudo apt-get install zlib1g-dbg
sudo apt-get install zlib1g
sudo apt-get install zlib1g-dev
sudo apt-get install libjasper-dev
sudo apt-get install libjasper-runtime
sudo apt-get install libjasper1
sudo apt-get install pngtools
sudo apt-get install libtiff4-dev
sudo apt-get install libtiff4
sudo apt-get install libtiffxx0c2
sudo apt-get install libtiff-tools
sudo apt-get install libjpeg8
sudo apt-get install libjpeg8-dev
sudo apt-get install libjpeg8-dbg
sudo apt-get install libjpeg-prog
sudo apt-get install ffmpeg
sudo apt-get install libavcodec-dev
sudo apt-get install libavcodec52
sudo apt-get install libavformat52
sudo apt-get install libavformat-dev
sudo apt-get install libgstreamer0.10-0-dbg
sudo apt-get install libgstreamer0.10-0
sudo apt-get install libgstreamer0.10-dev
sudo apt-get install libxine1-ffmpeg
sudo apt-get install libxine-dev
sudo apt-get install libxine1-bin
sudo apt-get install libunicap2
sudo apt-get install libunicap2-dev
sudo apt-get install libdc1394-22-dev
sudo apt-get install libdc1394-22
sudo apt-get install libdc1394-utils
sudo apt-get install swig
sudo apt-get install libv4l-0
sudo apt-get install libv4l-dev
sudo apt-get install python-numpy
sudo apt-get install libgtk2.0-dev
sudo apt-get install libjpeg62-dev
sudo apt-get install libopenexr-dev
sudo apt-get install python-dev
sudo apt-get install libtbb-dev
sudo apt-get install libeigen2-dev
sudo apt-get install yasm
sudo apt-get install libfaac-dev
sudo apt-get install libopencore-amrnb-dev
sudo apt-get install libopencore-amrwb-dev
sudo apt-get install libtheora-dev
sudo apt-get install libvorbis-dev
sudo apt-get install libxvidcore-dev

tar -xvf opencv-2.4.6.1.tar.gz -C /usr/share

cd /usr/share/opencv-2.4.6.1/
 
mkdir build
cd build

cmake -D WITH_TBB=ON -D BUILD_NEW_PYTHON_SUPPORT=ON -D WITH_V4L=OFF -D INSTALL_C_EXAMPLES=ON -D INSTALL_PYTHON_EXAMPLES=ON -D BUILD_EXAMPLES=ON ..

make

sudo make install

echo "/usr/local/lib" >> /etc/ld.so.conf.d/opencv.conf

sudo ldconfig

export LD_LIBRARY_PATH=/usr/local/lib

cd

echo "PKG_CONFIG_PATH=$PKG_CONFIG_PATH:/usr/local/lib/pkgconfig" >> .bashrc
echo "export PKG_CONFIG_PATH" >> .bashrc

source ~/.bashrc

#Reboot the system aftewards
#http://ubuntuone.com/5wv5iK5BzW6sKoNzja4H6s (Link to download this text file)
